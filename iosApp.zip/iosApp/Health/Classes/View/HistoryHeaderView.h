//
//  HistoryHeaderView.h
//  Health
//
//  Created by Administrator on 9/12/14.
//  Copyright (c) 2014 projectvision. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryHeaderView : UIView

@property (nonatomic, retain) IBOutlet UILabel      *challengeLabel;

@end
