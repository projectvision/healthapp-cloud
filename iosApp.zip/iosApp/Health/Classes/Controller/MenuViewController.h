//
//  MenuViewController.h
//  Health
//
//  Created by Administrator on 8/29/14.
//  Copyright (c) 2014 projectvision. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuViewController : UIViewController
{
    IBOutlet UITableView        *menuTableView;
}

@end
