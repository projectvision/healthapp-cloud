//
//  Reward.m
//  Health
//
//  Created by Administrator on 9/7/14.
//  Copyright (c) 2014 projectvision. All rights reserved.
//

#import "Reward.h"

@implementation Reward
@synthesize rewardId;
@synthesize challengeId;
@synthesize level;
@synthesize challnege;
@synthesize point;

@end
