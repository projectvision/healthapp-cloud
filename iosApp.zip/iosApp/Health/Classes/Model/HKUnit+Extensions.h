//
//  HKUnit+Extensions.h
//  Yabbit
//
//  Created by Apple on 27/05/16.
//  Copyright © 2016 projectvision. All rights reserved.
//

@import HealthKit;

@interface HKUnit (GSHealthKitManager)
+ (HKUnit *)heartBeatsPerMinuteUnit;
@end
