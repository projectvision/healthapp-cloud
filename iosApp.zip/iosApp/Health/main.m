//
//  main.m
//  Health
//
//  Created by Administrator on 8/28/14.
//  Copyright (c) 2014 projectvision. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HealthAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool
    {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HealthAppDelegate class]));
    }
}
